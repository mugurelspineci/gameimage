package com.lightcone.mapoverlaydemo;

import android.app.Activity;
import android.os.Bundle;
import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Toast;

public class MapOverlayDemo extends Activity implements OnClickListener {

	static Context context;
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        // Get application context for later use
        context = getApplicationContext();
        
        // Add ClickListener for the button
        View firstButton = findViewById(R.id.mapshow_button);
        firstButton.setOnClickListener(this); 
    }

	@Override
	public void onClick(View v) {
		double lat = 35.955;
		double lon = -83.9265;
		switch(v.getId()){
			case R.id.mapshow_button:		
					Intent i = new Intent(this, ShowTheMap.class);
					ShowTheMap.putLatLong(lat, lon);
					startActivity(i);
			break;		
		}	
	}
	
	// Create a static method to show toasts (not presently used but included
	// as an example)
	
	public static void showToast(String text){
		Toast.makeText(context, text, Toast.LENGTH_LONG).show();
	}
	
}