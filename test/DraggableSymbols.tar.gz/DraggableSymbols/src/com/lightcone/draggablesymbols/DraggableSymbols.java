package com.lightcone.draggablesymbols;

import android.app.Activity;
import android.os.Bundle;
import android.view.ViewGroup;

/*
Demonstration of one way to put a set of draggable symbols on screen. Define symbols as image 
files in res/drawable-hdpi/filename.png (or .jpg or .gif files). Refer to them then by 
R.drawable.filename in the array symbolIndex, and give the initial x and y coordinates for 
each symbol in the arrays X and Y.
*/

public class DraggableSymbols extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        // Define the symbols and their initial coordinates in arrays. No limit in principle 
        // to how many. Coordinates are measured from the upper left corner of the screen, 
        // with x increasing to the right and y increasing downward
        
        float [] X = {2, 48, 94};   // Initial x coord in pixels of upper left corner of symbol
        float [] Y = {2, 2, 2};     // Initial y coord in pixels of upper left corner of symbol
        
        // The Drawable corresponding to the symbol. R.drawable.file refers to file.png, .jpg, 
        // or .gif stored in res/drawable-hdpi (referenced from code without the extension).
        
        int[]symbolIndex = {R.drawable.red_square, R.drawable.green_square, R.drawable.yellow_square};
        
        // Instantiate a SymbolDragger instance (which subclasses View), passing to it in the
        // constructor the context (this) and the above arrays.  Then set the content view to 
        // this instance of SymbolDragger (so the layout is being specified entirely by SymbolDragger, 
        // with no XML layout file).  The resulting view should then place draggable symbols with 
        // content and initial position defined by the above arrays on the screen.
        
        SymbolDragger view = new SymbolDragger(this, X, Y, symbolIndex);
        view.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.FILL_PARENT,
             ViewGroup.LayoutParams.FILL_PARENT));
        setContentView(view);
    }
}