package com.xebia.chart.googlechartapi;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;

public class GoogleChartDemo extends Activity {
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		WebView googleChartView = new WebView(this);
		setContentView(googleChartView);
		String mUrl = "http://chart.apis.google.com/chart?cht=p3&chd=t:30,60,10&chs=250x100&chl=cars|bikes|trucks";
		googleChartView.loadUrl(mUrl);
	}

	@Override
	protected void onResume() {
		super.onResume();
	}

}
