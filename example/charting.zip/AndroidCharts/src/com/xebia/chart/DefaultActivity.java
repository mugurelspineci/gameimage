package com.xebia.chart;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

import com.xebia.chart.achartexample.AChartExample;
import com.xebia.chart.chartdroid.ChartDroidDataProvider;
import com.xebia.chart.googlechartapi.GoogleChartDemo;

public class DefaultActivity extends Activity implements OnClickListener {
	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		registerListeners();
	}

	private void registerListeners() {
		Button googleChartButton = (Button) findViewById(R.id.googleChart);
		googleChartButton.setOnClickListener(this);
		Button achartButton = (Button) findViewById(R.id.achart);
		achartButton.setOnClickListener(this);
		Button chartDroidButton = (Button) findViewById(R.id.chartdroid);
		chartDroidButton.setOnClickListener(this);

	}

	@Override
	public void onClick(View v) {
		System.out.println(v.getId());
		switch (v.getId()) {
		case R.id.googleChart:
			Intent googleChart = new Intent(this, GoogleChartDemo.class);
			startActivity(googleChart);
			break;
		case R.id.achart:
			Intent achartIntent = new AChartExample().execute(this);
			startActivity(achartIntent);
			break;
		case R.id.chartdroid:
			Intent chartDroidIntent = new Intent(Intent.ACTION_VIEW,
					ChartDroidDataProvider.PROVIDER_URI);
			chartDroidIntent.putExtra(Intent.EXTRA_TITLE, "Chart droid");
			chartDroidIntent
					.addCategory("com.googlecode.chartdroid.intent.category.PIE_CHART");
			startActivity(chartDroidIntent);
			break;
		}

	}
}