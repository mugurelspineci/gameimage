package com.xebia.chart.chartdroid;

import android.content.ContentProvider;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.provider.BaseColumns;

public class ChartDroidDataProvider extends ContentProvider {

	static final String AUTHORITY = "com.xyz.contentprovider.chardroid";

	@Override
	public int delete(Uri uri, String selection, String[] selectionArgs) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public String getType(Uri uri) {
		return "vnd.android.cursor.dir/vnd.com.googlecode.chartdroid.graphable";
	}

	@Override
	public Uri insert(Uri uri, ContentValues values) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean onCreate() {
		// TODO Auto-generated method stub
		return false;
	}

	public static final Uri PROVIDER_URI = new Uri.Builder().scheme(
			ContentResolver.SCHEME_CONTENT).authority(AUTHORITY).build();

	@Override
	public Cursor query(Uri uri, String[] projection, String selection,
			String[] selectionArgs, String sortOrder) {

		// Fetch the actual data

		MatrixCursor c = new MatrixCursor(new String[] { BaseColumns._ID,
				"COLUMN_AXIS_INDEX", "COLUMN_SERIES_INDEX",
				"COLUMN_DATUM_VALUE", "COLUMN_DATUM_LABEL" });

		c.newRow().add(1).add(0).add(1).add(30).add(null);
		c.newRow().add(2).add(0).add(1).add(10).add(null);
		c.newRow().add(3).add(0).add(1).add(60).add(null);

		return c;
	}

	@Override
	public int update(Uri uri, ContentValues values, String selection,
			String[] selectionArgs) {
		// TODO Auto-generated method stub
		return 0;
	}

}
